function res = times(a,b)

res = mtimes(a,b);
